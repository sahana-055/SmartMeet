let currentUser = null;

let meeting = {
  title: "",
  slots: [],
  votes: {},
  usersVoted: {}
};

let votingDuration = 3 * 60 * 60; // 3 hours
let timerInterval = null;
let votingClosed = false;

/* LOGIN */
function login() {
  const name = document.getElementById("username").value.trim();
  if (!name) return alert("Enter your name");

  currentUser = name;
  document.getElementById("loginCard").classList.add("hidden");
  document.getElementById("app").classList.remove("hidden");
}

/* ADD SLOT */
function addSlot() {
  const slot = document.getElementById("timeSlot").value.trim();
  if (!slot || meeting.slots.includes(slot)) return;

  meeting.slots.push(slot);
  meeting.votes[slot] = 0;

  const li = document.createElement("li");
  li.textContent = slot;
  document.getElementById("slotList").appendChild(li);

  document.getElementById("timeSlot").value = "";
}

/* CREATE MEETING */
function createMeeting() {
  const title = document.getElementById("meetingTitle").value.trim();
  if (!title || meeting.slots.length === 0)
    return alert("Add title and at least one slot");

  meeting.title = title;
  votingClosed = false;
  votingDuration = 3 * 60 * 60;

  document.getElementById("currentMeeting").innerText =
    `${meeting.title} (👥 0)`;

  startTimer();
  renderVoting();
}

/* VOTE */
function vote(slot) {
  if (votingClosed) return alert("Voting time is over");

  const previous = meeting.usersVoted[currentUser];
  if (previous) meeting.votes[previous]--;

  meeting.usersVoted[currentUser] = slot;
  meeting.votes[slot]++;

  document.getElementById("currentMeeting").innerText =
    `${meeting.title} (👥 ${Object.keys(meeting.usersVoted).length})`;

  renderVoting();
}

/* RENDER */
function renderVoting() {
  const voteSection = document.getElementById("voteSection");
  voteSection.innerHTML = "";

  const totalVotes = Object.keys(meeting.usersVoted).length;

  meeting.slots.forEach(slot => {
    const percent =
      totalVotes === 0 ? 0 : Math.round((meeting.votes[slot] / totalVotes) * 100);

    const voted = meeting.usersVoted[currentUser] === slot;

    voteSection.innerHTML += `
      <div class="vote-box">
        <p>${slot} ${voted ? '<span class="tick">✔</span>' : ''} <strong>${percent}%</strong></p>
        <div class="progress">
          <div class="progress-fill" style="width:${percent}%"></div>
        </div>
        <button onclick="vote('${slot}')">Select</button>
      </div>
    `;
  });

  finalizeTime();
}

/* TIMER */
function startTimer() {
  clearInterval(timerInterval);

  timerInterval = setInterval(() => {
    if (votingDuration <= 0) {
      clearInterval(timerInterval);
      votingClosed = true;
      document.getElementById("timer").innerText = "Voting Closed";
      finalizeTime(true);
      return;
    }

    const h = Math.floor(votingDuration / 3600);
    const m = Math.floor((votingDuration % 3600) / 60);
    const s = votingDuration % 60;

    document.getElementById("timer").innerText =
      `Voting ends in ${h}h ${m}m ${s}s`;

    votingDuration--;
  }, 1000);
}

/* FINALIZE */
function finalizeTime(lock = false) {
  let best = "Not finalized";
  let max = 0;

  for (let slot in meeting.votes) {
    if (meeting.votes[slot] > max) {
      max = meeting.votes[slot];
      best = slot;
    }
  }

  document.getElementById("finalTime").innerText =
    lock ? `${best} ✅ (Finalized)` : best;
}
